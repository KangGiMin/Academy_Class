
public class TestMain {

	public static void main(String[] args) {
		
		try {
			int  n1 = 7;
			int  n2 = 0;
			int  n  = n1 / n2;
			System.out.println(n);
		} catch (Exception e) {			
			//e.printStackTrace();
			System.out.println("분모는 0 이 X");
		} finally {
			System.out.println("종료");			
		}

	}

}
