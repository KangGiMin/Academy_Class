<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
 <% 
     String s1 = "<h2>Hello</h2>";
     String s2 = "<p>Hello</p>";
 %>   
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
  <%=s1 %>
  <%=s2 %>
</body>
</html>