<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%
   
    request.setCharacterEncoding("utf-8");  // 넘어오는 정보 한글처리	
    String  dong  =  request.getParameter("dong");
	String  html  =  "";
	if( dong == null ) {
		
	} else {
	    PostDao db = new PostDao();
	    List<PostDto> list = db.getPost( dong );
		html += "";
	}
		

%>    
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
   <form action="#" method="get">
   동명/건물명<input type="text" name="dong" />
   <input type="submit" value="검색" />
   </form>    
   <div>
   <%= html %> 
   </div>
</body>
</html>






