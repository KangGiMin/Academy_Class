package post;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PostDao {

	public List<PostDto>  getPost( String dong ) {
		
		List<PostDto> list = new ArrayList<>(); 
		
		DBConn             db    =  new DBConn();
		Connection         conn  =  db.getConnection();
		String             sql   =  "";
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
		//	pstmt.close();
		//	conn.close();
		}
		
		return  list;
		
	}
}




