package post;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConn {
	private String  driver  = "oracle.jdbc.OracleDriver";
	private String  dburl   = "jdbc:oracle:thin:@192.168.0.22:1521:xe";
	private String  dbuid   = "zipcode";
	private String  dbpwd   = "1234";
	
	private  Connection   conn = null;
	
	public  Connection  getConnection() {
		
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(dburl, dbuid, dbpwd);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return conn;
	}
}





