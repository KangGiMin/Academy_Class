package iter02;

import java.util.Iterator;

public class TestNestedFor01 {
	/*  star01(), star02()
	 1     2 
i   j12345	 
1	 ***** \n
2	 ***** \n
3	 ***** \n
4	 ***** \n
5	 ***** \n
	 */
	
	/* star03()
row
     column
     12345
1	 *        \n
2	 **       \n
3	 ***      \n
4	 ****     \n
5	 *****    \n
	 */
	
	public static void main(String[] args) {
		//System.out.print("카리나\n");
		//System.out.print("윈터\n");
		star01();
		star02();
		star03();
		star04();
		star05();	
		
	}	
	
	
	// star01()
	private static void star01() {
		System.out.println("1.");
		for (int i = 1; i <= 5; i++) {
			System.out.print("*****\n");
		}		
	}
	
	// star02()
	private static void star02() {
		System.out.println("2.");
		
		// 중첩 반복 nested for 
		for (int i = 1; i <= 5; i++) {   // 줄 row : i
			/*
			System.out.print("*");  // 1  칸 column : j
			System.out.print("*");  // 2
			System.out.print("*");  // 3
			System.out.print("*");  // 4
			System.out.print("*");  // 5
			*/
			for (int j = 1; j <=5; j++) {
				System.out.print("*");
			}
			
			System.out.print("\n");
		}		
		
	}

	// star03()
	private static void star03() {
		System.out.println("3.");
		for (int i = 1; i <=5 ; i++) {
			//1 
			for (int j = 1; j <= i; j++) {
				// System.out.print( j );
				System.out.print( "*" );
			}
			//2
			System.out.print("\n");
		}
		
	}

	// star04()
	private static void star04() {
		System.out.println("4.");
		for (int i = 1; i <=5; i++) {
			for (int j = 1; j <= 6-i; j++) {
				System.out.print("*");				
			}
			System.out.print("\n");
		}		
		
	}
	
	private static void star05() {
		System.out.println("5.");
		for (int i = 1; i <=5 ; i++) {
			
			for (int j1 = 1; j1 <= 5-i; j1++) {
				System.out.print(" ");
			}
			
			for (int j2 = 6-i; j2 <=5; j2++) {
				System.out.print("*");
			}
			System.out.print("\n");
		}
	}
	
	private static void star06() {
		System.out.println("06");
		for(int i=1; i<=5;i++) {
			for(int j1=1; j1<=i-1; j1++ ) {
				System.out.print(" ");
			}
			for(int j2=i;j2<=5;j2++) {
				System.out.print("*");
			}
			System.out.println(); //  == System.out.print("\n")
		}
	}

}

















