package iter01;

import java.util.Iterator;

public class TestFor01 {

	public static void main(String[] args) {
		
		System.out.println("닝닝");  // 1
		System.out.println("닝닝");  // 2
		System.out.println("닝닝");  // 3
		System.out.println("닝닝");  // 4
		System.out.println("닝닝");  // 5
		System.out.println();
		
		for( int i=1; i<=5 ; i++  ) {
			System.out.println(i + "닝닝");
		}
		System.out.println();
		
		int i=1;
		while( i <= 5 ) {
			System.out.println(i + "닝닝");
			i++;
		}
			

	}

}








