package iter01;

public class TestFor02 {
	
	private static void func1() {
		// 1
		int sum1 = 1+2+3+4+5+6+7+8+9+10;
		System.out.println( sum1 );
	}
	
	private static void func2() {
		int n = 10;
		int sum2  =  n / 2 * (n+1);
		System.out.println( sum2 );
	}
	
	private static void func3() {
		int j = 0;
		int sum = 0;
		for(int i=1;i<=10;i++) {
			j = j + 1;
			sum = sum + j;
			System.out.println(i + " " +  j + " " +  sum);
		}
		System.out.println(sum);
		
	}
	
	private static void func4() {
		// 1+3+5+7+9+11+13+..+99= 2500
		int j   = -1;
		int sum = 0;
		for(int i=1; i<=50; i=i+1 ) {
			j   = j + 2;
			sum = sum + j;
		}
		System.out.println( sum );
		
	}


	public static void main(String[] args) {
		
		int n = Integer.MAX_VALUE;
		System.out.println(n);  // 2147483647
		n =  n + 2;
		System.out.println(n);  // -2147483647
		
		func1();
		func2();
		func3();
		func4();
		func5();
		func6();
		func7();
		func8();
		func8_2();
		func9();
		
	}
	
	// 무한 반복(무한 루프)
	// for( ; ; ) {
	//    if(탈출조건) break;
	// }
	// while(true) {
	//  if(탈출조건) break;
	// }

	private static void func9() {
		// 피보나치 수열
		// 1+1+2+3+5+8+13+21+.. 
		// 30번째 값은 얼마입니까 i = 30
		// 최대 90번째까지 계산가능 long
		long j1  = 0;
		long j2  = 1;
		long j   = 0;
		long sum = 0;
		for (int i = 1; i <= 100; i++) {
			j   = j1  + j2;
			sum = sum + j;
			j2  = j1;
			j1  = j; 
			System.out.println( i + ":" + sum );
		}
		System.out.println("sum=" + sum);		
		
	}

	private static void func8_2() {
		// (1)  + (2+4+8+16+...+128)=

		int  j    = 1;	
		int  sum1 = 1;
		int  sum2 = 0;
		int i = 1;
		while ( j <= 128 ) {
			j     = j * 2;
			sum2 += j;
			i++;
		}		
		int  sum = sum1 + sum2;
		System.out.println(sum);
		
	}

	private static void func8() {
		// Math.pow(2, i-1)
		// (1+2+4+6+8+16+...+128) =   511
		int j   = 0; 
		int sum = 0;
		for (int i = 1; j <= 128; i++) {
			j = (int) Math.pow(2, i-1);
			sum = sum + j;
		}
		System.out.println( sum );
		
	}

	private static void func7() {
		// 1+1+2+1+2+3+1+2+3+4+1+2+3+4+5= 35
		int j   = 0;
		int sum = 0;
		for (int i = 1; i <= 5; i++) {
			j   = j + i;
			sum = sum+j; 
		}
		System.out.println( sum   );
		
	}

	private static void func6() {
		int sum = 0;
		for (int i = 2; i <= 100; i += 2 ) {
			sum = sum + i;
		}
		System.out.println(sum);
		
	}

	private static void func5() {
		// 2+4+6+...+98+100= 2550
		int j   = 0;
		int sum = 0;
		for (int i = 1; i <= 50; i++) {
			j   += 2;   // j   = j + 2;
			sum += j;   // sum = sum +j;
		}
		System.out.println(sum );
		
	}

	

	
}













