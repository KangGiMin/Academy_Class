package iter01;

import java.math.BigInteger;

public class TestFibo {

	public static void main(String[] args) {
	    int n = 100;

        BigInteger[] fib = new BigInteger[n + 1];
        fib[0] = BigInteger.ZERO;
        fib[1] = BigInteger.ONE;

        for (int i = 2; i <= n; i++) {
            fib[i] = fib[i - 1].add(fib[i - 2]);
        }

        System.out.println("100번째 피보나치 수: ");
        System.out.println(fib[100]);
    }

}
