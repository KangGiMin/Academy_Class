package ex05;

class Member {
	private  int     id;
	private  String  name;
	private  String  email;
	
	/*
	// getter
	public   int    getId() {
		return  id;
	}
	// setter
	public   void   setId( int id ) {
		this.id  = id;
	}
	*/
	
	
	// toString
	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", email=" + email + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}

public class TestMember {

	public static void main(String[] args) {
		Member m1 = new Member();
		m1.setId(1);   
		m1.setName("유진");
		m1.setEmail("yg@ive.com");
		   // m1.id = 1; // 에러
		System.out.println( m1 );
		System.out.println( m1.getId() );    
		  //  System.out.println( m1.id );  // 에러

	}

}




