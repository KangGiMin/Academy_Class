package ex07;
/*
입력 : 번호 이름 국어 영어 수학 
출력 : 번호 이름 국어 영어 수학 총점 평균 학점 : 잘했음(100점 짜리가 있을때

모든 필드는 private
   생성자나 getter/setter, toString 으로 프로그램 작성
*/

class Student {
	// Data : Fields
	// 입력 : 번호 이름 국어 영어 수학
	private  int      num;
	private  String   name;
	private  int      kor;
	private  int      eng;
	private  int      mat;
	
	// 출력 : 번호 이름 국어 영어 수학 총점 평균 학점 : 잘했음
//	private  int      tot;
//	private  double   avg;
//	private  char     grade;
//	private  String   comment;
		
	// Constructor : 인자 있는 생성자
	public Student(int num, String name, int kor, int eng, int mat) {
		this.num = num;
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
	}
	

	// Operation : Method
	public void output() {
		// 번호 이름 국어 영어 수학 총점 평균 학점 : 잘했음
		System.out.printf("%3d  %-7s %3d %3d %3d %3d %7.3f %3c %s\n",
				this.num, this.name,   this.kor,    this.eng,     this.mat,
				getTot(), getAvg(),  getGrade() , getGood() );
		
	}	

    // getter
	public int getNum() {
		return num;
	}

	public String getName() {
		return name;
	}

	public int getKor() {
		return kor;
	}

	public int getEng() {
		return eng;
	}

	public int getMat() {
		return mat;
	}

	public String getGood() {
		String good = "";
		if( this.kor == 100   ) good = "잘했음";
		if( this.eng == 100   ) good = "잘했음";
		if( this.mat == 100   ) good = "잘했음";
		return good;
	}

	public char getGrade() {
		//                  0   1   2   3   4   5   6   7   8   9   10  
		char [] g      = { 'F','F','F','F','F','F','D','C','B','A','A'  };  
		char    grade  = g[ (int) getAvg() / 10  ];
		return  grade;
	}

	public double getAvg() {
		double  avg = (double) getTot() / 3.0;
		return avg;
	}

	public int getTot() {
		int     tot = this.kor + this.eng + this.mat;
		return    tot;
	}

	// override method
	// 객체의값을 확인하는 용도
	@Override
	public String toString() {
		return "Student [num=" + num + ", name=" + name + ", kor=" + kor + ", eng=" + eng + ", mat=" + mat + "]";
	}

	
	
}

public class TestStudent {

	public static void main(String[] args) {
		//Student s1 = new Student();
		// s1.name = "이순신";
		System.out.println("번호 이름    국어 영어 수학 총점 평균 학점 평가");
		Student  s1 = new Student(1, "이순신", 100, 90, 80 );
		s1.output();
		
		//System.out.println( s1 );   // s1.toString()
		Student  s2 = new Student(2, "강감찬", 80, 90, 90);
		s2.output();
		//System.out.println( s2 );
		
		System.out.println( "s2의 이름은 " + s2.getName() );
		System.out.println( "s2의 이름은 " + s2.getAvg() );
		System.out.println( "s2의 등급은 " + s2.getGrade() );
		
		//System.out.println( s1.name );

	}

}



