package ex06;

class  Member {
	// fields
	private  int     id;
	private  String  name;
	private  String  email;
	
	// Constructor : 값을 저장할려고 setter 대신
	public Member(int id, String name, String email) {
		this.id = id;
		this.name = name;
		this.email = email;
	}
	
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	// toString
	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", email=" + email + "]";
	}
	
}

public class TestMember {

	public static void main(String[] args) {
		Member m1 = new Member(3, "유나", "yuna@yg.com");
		System.out.println( m1 );
		System.out.println( m1.getName()  );

	}

}






