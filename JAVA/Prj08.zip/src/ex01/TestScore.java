package ex01;


// 모든 class 의 부모
// Object 객체이고 미리 만들어져 있다
// obj1.hashCode()  : 객체의 Heap 메모리 상의 위치 : 주소
// obj1.toString()  : 객체의 기본정보출력  패키지이름.클래스이름@해시코드
// obj1.equals()    : 객체를 비교 
// obj1.getClass()  :  class ex01.Student
// 자바의 class 기본적으로 Object class를 상속받아서 만들어진다

class  Student extends Object {
	
}

public class TestScore {

	public static void main(String[] args) {
		Object obj1 = new Object();
		
		Student  s1 = new Student();
		System.out.printf( "s1 의 Heap 메모리상의 위치 : %x\n", s1.hashCode() );
		System.out.println( s1.toString() );
		System.out.println( s1.getClass() );
		

	}

}







