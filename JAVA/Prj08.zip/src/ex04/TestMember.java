package ex04;

class Member {
	private int     id;
	private String  name;
	private String  email;
	
	//Constructor
	public Member(int id, String name, String email) {
		this.id    = id;
		this.name  = name;
		this.email = email;
	}

	// toString
	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", email=" + email + "]";
	}
	
}

public class TestMember {

	public static void main(String[] args) {
		//Member m1  = new Member();
		//m1.id      = 1;
		//System.out.println( m1.id );
		Member m1 = new Member(1, "원영", "10@girls.com");
		System.out.println( m1 );

	}

}






