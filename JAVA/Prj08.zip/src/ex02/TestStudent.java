package ex02;

/*
num,name,kor,eng,mat
번호,이름,국어,영어,수학
1,사나,70,80,90
2,모모,0,70,100
3,쯔위,70,90,90
4,정연,80,90,70
5,원영,90,90,89
6,유진,100,100,100
*/

class Student {
//입력:번호,이름,국어,영어,수학
//출력:번호 이름 국어 영어 수학 총점 평균
	// field
	// 입력
	int      num;
	String   name;
	int      kor;
	int      eng;
	int      mat;
	
	// 출력
	int      tot;
	double   avg;
	char     grade;
	
	// alt + shift + s : generate Constructor using Field
	// constructor : new 할때 입력data 를 객체안에 넣어주는 
	public Student(int num, String name, int kor, int eng, int mat) {
		this.num = num;
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
	}
	
	//  메소드
	// 총점 계산
	void calcTot() {
		this.tot = kor + this.eng + this.mat;
	}
	
	// 평균 계산
	void calcAvg() {
		this.avg = (this.kor + this.eng + this.mat) / 3.0;
	}
	
	// 등급계산
	// 90~100      : A   90 <= x <= 100 -> 90 <= x && x<= 100  
	// 80~89.999   : B
	// 70~79.999  : C
	// 60~69.999   : D
	// 0~59.999    : F
	void calcGrade() {
		this.grade = 'F';   
		if( 90 <= avg && avg <= 100  )
			this.grade = 'A';
		else 
			if( 80 <= avg && avg < 90  ) 
				this.grade = 'B';
			else
				if( 70 <= avg && avg < 80  ) 
					this.grade = 'C';
				else
					if( 60 <= avg && avg < 70  ) 
						this.grade = 'D';
	}
	
	// 출력
	public void output() {
		calcTot();
		calcAvg();
		calcGrade();
		
		System.out.printf( 
				"%3d  %s  %3d  %3d  %3d  %3d  %7.3f %3c\n",
				 this.num , this.name, this.kor, this.eng, this.mat,
				 this.tot, this.avg, this.grade );		
	}
	
	
}

public class TestStudent {

	public static void main(String[] args) {
		
		System.out.println("번호 이름 국어 영어 수학 총점 평균 등급");
		Student  s1  =  new Student(1,"사나",70,80,90);
		s1.output();
		Student  s2  =  new Student(2,"모모",0,70,100);
		s2.output();
		Student  s3  =  new Student(3,"쯔위",70,90,90);
		s3.output();
		Student  s4  =  new Student(4,"정연",80,90,70);
		s4.output();
		Student  s5  =  new Student(5,"원영",90,90,89);
		s5.output();
		Student  s6  =  new Student(6,"유진",100,100,100);
		s6.output();		

	}

}






