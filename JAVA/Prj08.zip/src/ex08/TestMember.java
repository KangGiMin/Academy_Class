package ex08;

import java.util.Objects;
import java.util.Scanner;

class Member {
	// Fields
	private  int      num;
	private  String   name;
	private  String   tel;
	
	// 생성자  : Constructor	
	public Member(int num, String name, String tel) {
		this.num  = num;
		this.name = name;
		this.tel  = tel;
	}

	public Member(int num, String name) {
		this.num  = num;
		this.name = name;
	}

	// Getter
	public String getName() {
		return name;
	}

	// 객체를 비교할 때는 반드시 equals() 를 재정의하라
	// 번호 비교, 이름 비교
	/*
	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		// 내객체의 번호      : this.num
		// 비교할 객체의 번호 : mArr[7].num -> other.num
		Member other = ( Member )  obj;
		if(this.num == other.num && this.name.equals(other.name) ) 
			result = true;
		return  result;
	}*/
	

	// toString 
	@Override
	public String toString() {
		return "Member [num=" + num + ", name=" + name + ", tel=" + tel + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Member other = (Member) obj;
		return Objects.equals(name, other.name) && num == other.num;
	}

}

public class TestMember {

	public static void main(String[] args) {
		// 여러명의 멤버정보를 입력하고
		// 찾을 멤버정보를 입력받아서 해당멤버으리 정보를 출력
		/*
		Member   m1  =  new Member(1, "민지",   "010");
		Member   m2  =  new Member(3, "카라니", "011");
		Member   m3  =  new Member(4, "원영",   "016");
		Member   m4  =  new Member(2, "윈터",   "017");
		Member   m5  =  new Member(5, "유진",   "018");
		
		System.out.println( m1 );
		System.out.println( m2 );
		System.out.println( m3 );
		System.out.println( m4 );
		System.out.println( m5 );
		*/
		
		/*
		Member [] mArr = new Member[10]; 
		mArr[0]  =  new Member(1, "민지",   "010"); 
		mArr[1]  =  new Member(3, "카라니", "011");
		mArr[2]  =  new Member(4, "원영",   "016");
		mArr[3]  =  new Member(2, "윈터",   "017");
		mArr[4]  =  new Member(5, "유진",   "018");
		mArr[5]  =  new Member(8, "제니",   "019");
		mArr[6]  =  new Member(10, "리사",   "020");
		*/
		

		Member [] mArr = new Member[] {
			new Member(1,  "민지",   "010"), 
			new Member(3,  "카리나", "011"),
			new Member(4,  "원영",   "016"),
			new Member(2,  "윈터",   "017"),
			new Member(5,  "유진",   "018"),
			new Member(8,  "제니",   "019"),
			new Member(10, "리사",   "020"),
			new Member(9,  "유나",   "013"),
			new Member(13, "유진",   "012"),
		};		
	
		// 전체 멤버의 정보를 출력
		for (int i = 0; i < mArr.length; i++) {
			if( mArr[i] == null ) 	break;
			System.out.println( mArr[i] );
		}
		
		// 키보드를 준비하고
		Scanner  in = new Scanner(System.in);
		System.out.println("이름을 입력하셈");
		String  inputName = in.nextLine();				
		
		// 유나의 정보를 출력 : 비교
		// 1. 객체의 name 을 가져와서 이름을 비교 찾는다 : 배열방 갯수 만큼
		String  result = "못찾았다";
		for (int i = 0; i < mArr.length; i++) {
			if(  mArr[i].getName().equals( inputName )  ) {
				result  = mArr[i].toString();
				break;
			}
		}
		System.out.println( "결과:" +  result );
		System.out.println("=====");
		
		
		// 2. 번호, 이름이 같은 멤버를 찾는다
		// 객체 비교
		// 비교할 객체(m)를 추가해서 객체끼리 비교
		// 비교할 번호 13, 비교할 이름 "유진"
		Member   m   =  new  Member(13, "유진");
		for (int i = 0; i < mArr.length; i++) {
			if( m.equals(mArr[i]) ) 
				System.out.println("찾았다" + mArr[i]);		
		}
		System.out.println("--------------");
		
		
		/*
		System.out.println( mArr[0] );
		System.out.println( mArr[1] );
		System.out.println( mArr[2] );
		System.out.println( mArr[3] );
		System.out.println( mArr[4] );
		*/

	}

}







