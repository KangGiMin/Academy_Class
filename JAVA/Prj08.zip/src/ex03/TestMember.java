package ex03;

import java.util.Objects;

class Member {
	int     id;
	String  name;
		
	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}

	// m2.equals( m )
	// 파라미터가 (Object obj 인 것은 모든 타입을 인자롤 사용할 수 있다
	@Override
	public boolean equals(Object obj) { 
		  // override 된 메소드 : 인자의 타입도 부모의 타입과 같아야한다
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if ( this.getClass() != obj.getClass()) // 둘다 Member type 인가
			return false;
		 
		Member other = (Member) obj; // obj(Object) ( <- m(Member))가  
		return this.id == other.id 
			 	&& this.name.equals( other.name );
			//	&& Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + "]";
	}
	
}

public class TestMember {

	public static void main(String[] args) {
		
		Member m1 = new Member();
		m1.id     = 1;
		m1.name   = "카리나";
		// `System.out.println( m1 );   // m1.toString() ex03.Member@28a418fc
		System.out.println( m1.toString() );   // m1.toString() ex03.Member@28a418fc
		
		Member m2 = new Member();
		m2.id     =  2;
		m2.name   = "윈터";
		System.out.println( m2 );
		
		Member m3 = new Member();
		m3.id     = 3;
		m3.name   = "닝닝";
		System.out.println( m3 );
		
		//------------------------
		Member m  = new Member();
		m.id      = 2;
		m.name    = "윈터";
		System.out.println( m );
		
		if( m2 == m  )   //  == 주소비교 
			System.out.println("같다");
		else
			System.out.println("같지않다");  // 같지 않다
		
		// equals 를 재정의해서 필드의 값을 비교하여 객체의 동일여부를 판단한다
		if( m2.equals(m) ) // equals() 도 재정의하지 않으면 주소를 비교 
			System.out.println("같다");
		else
			System.out.println("같지않다");	
	}

}








