package ex09;
/* csv format- comma seperator variable
1,P01,10,1250.0
2,P02,15,2000.0
3,P03,30,1500.0
5,P04,25,2000.0
4,P05,28,1900.0
*/
  // 입력:번호,제품코드,수량,단가
  //      num, pcode, amount, price
  // P01:새우깡, P02:빅파이, P03:짱구, P04:초코파이, P05:수박맛초코파이
  // 출력:번호,제품명,수량,단가,금액(수량*단가)
  //      num, pname, amount, price, kum 

import java.util.Arrays;
import java.util.Scanner;

interface Ipo {
	void   input();
	void   process();
	void   output();
}

// data class  : 1,P01,10,1250.0
class ProdDTO {
	// 입력:번호,제품코드,수량,단가
	//      num, pcode, amount, price
	private  int     num;
	private  String  pcode;
	private  int     amount;
	private  double  price;

	// 출력:번호,제품명,수량,단가,금액(수량*단가)
	//      num, pname, amount, price, kum 
	private  String  pname;
	private  double  kum;


	public ProdDTO(int num, String pcode, int amount, double price) {
		this.num     = num;
		this.pcode   = pcode;
		this.amount  = amount;
		this.price   = price;
	}

	//toString
	@Override
	public String toString() {
		return "Prod [num=" + num + ", pcode=" + pcode + ", amount=" + amount + ", price=" + price + ", pname=" + pname
				+ ", kum=" + kum + "]";
	}

	// Getter
	public String getPcode() {
		return pcode;
	}

	public void setPname( String pname ) {
		this.pname = pname;		
	}

	public int getAmoun() {		
		return  this.amount;
	}

	public double getPrice() {		
		return  this.price;
	}

	public void setKum(double kum) {
		this.kum = kum;		
	}

	public String  getPname() {
		return   this.pname;
	}

	public Object getKum() {
		return   this.kum;
	}

	public Object getNum() {		
		return   this.num;
	} 	
}

// 업무처리 class
class Product  implements Ipo {
	
	private  ProdDTO  p;

	@Override
	public void input() {
		Scanner   in     =  new Scanner( System.in );
		
		System.out.println("입력:번호,제품코드,수량,단가");
		String    line    =  in.nextLine();     // "5,P04,25,2000.0"  
		                                  //  li  0  1     2     3                                         
		String [] li      =  line.split(",");   // "5" "P04" "25" "2000.0"
		// System.out.println( Arrays.toString( li ) );
		
		int      num      =  Integer.parseInt(   li[0] );  // 5 <-  "5"
		String   pcode    =  li[1];
		int      amount   =  Integer.parseInt(   li[2] );
		double   price    =  Double.parseDouble( li[3] );  // 2000.0 <- "2000.0"
		
		p                 =  new ProdDTO(num, pcode, amount, price); 
		System.out.println( p );
		
	}

	@Override
	public void process() {
		// P01:새우깡, P02:빅파이, P03:짱구, P04:초코파이, P05:수박맛오예쓰
		// 출력:번호,제품명,수량,단가,금액(수량*단가)
		//      num, pname, amount, price, kum
		
		String   pname = "";
		if( p.getPcode().equals("P01") ) 
			pname = "새우깡";
		else 
			if( p.getPcode().equals("P02") )
				pname = "빅파이";
			else
				if( p.getPcode().equals("P03") )
					pname = "짱구";
				else
					if( p.getPcode().equals("P04") )
						pname = "초코파이";
					else
						if( p.getPcode().equals("P05") )
							pname = "수박맛오예쓰";
		
		p.setPname( pname );
		
		double kum = p.getAmoun()  * p.getPrice(); // 수량 * 단가 ;
		p.setKum( kum );
		
		System.out.println( p );
		
	}

	@Override
	public void output() {
		
		System.out.println("번호 제품명      수량    단가    금액");
		System.out.printf("%3d  %-10s    %5d    %9.3f     %14.3f  \n", 
				p.getNum(), p.getPname(), p.getAmoun(), p.getPrice(),	p.getKum());
		
	}
	
}


public class TestProd {

	public static void main(String[] args) {

		Product  p  =  new Product();
		p.input();
		p.process();
		p.output();

	}

}












