package collection2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class TestHashSet {

	public static void main(String[] args) {
		
		Set<String> set = new HashSet<>() {};
		set.add("Java");
		set.add("Html");
		set.add("Oracle");
		set.add("Java");   // 중복은 저장되지 않는다
		set.add("Spring");
		System.out.println( set.size() );
		
		for (Iterator iterator = set.iterator(); iterator.hasNext();) {
			String subject = (String) iterator.next();
			System.out.println( subject );			
		}
				

	}

}









