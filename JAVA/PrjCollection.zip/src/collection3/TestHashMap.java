package collection3;

import java.util.HashMap;

public class TestHashMap {

	public static void main(String[] args) {
		HashMap<String, Object> map = new HashMap<>();
		
		map.put("num",     1);
		map.put("name",    "송중기");
		map.put("kor",     90);
		map.put("eng",     95);
		map.put("mat",     92);
		map.put("height",  178.3);
		
		System.out.println( map.size() );
		
		int     num   =  (int) map.get("num");
		// String name =    (String) map.get("name"); //x
		String  name  =  String.valueOf( map.get("name") ); 
		 // String.valueOf(모든 타입( -> string // Object -> String 
        String  val1  =  String.valueOf( 37.5 );   // 37.5 + "" 		
		int     kor   =  (int) map.get("kor");
		int     eng   =  (int) map.get("eng");
		int     mat   =  (int) map.get("mat");
		// int     tot   =  map.get("kor") + map.get("eng") + map.get("mat");
		// Object <- map.get("kor")        
        
		System.out.println( num  );
		System.out.println( name );
		System.out.println( kor  );
		System.out.println( eng  );
		System.out.println( mat  );
		
	}

}









