package collection1;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ListTest {

	public static void main(String[] args) {
		// 배열 -> arraylist
		String       [] names    =  {"홍길동", "이길동", "박길동", "최길동"};
		List<String>    nameList =  Arrays.asList(names);
				
		// nameList.add("전우치"); // error
		//  Arrays.asList(names) // size 변경불가능한 ArrayList로 변환
		
		// foreach
		for (String name : nameList) {
			System.out.print( name + ",");
		}
		System.out.println();
		
		// sort (ascending 정렬 순서대로) : asc
		//Collections.sort( nameList );
		// 함수의 인수가 함수 : callback 함수
		// (a, b)-> a.compareTo(b) : 람다식 -> 함수를 만드는 방법
		// boolean func(String a, String b) { 
		//    return a.compareTo(b); 
		// }
		// sort desc
		Collections.sort( nameList, (a, b)-> a.compareTo(b) ); // 오름차순
		// Collections.sort( nameList, (a, b)-> b.compareTo(a) ); // 내림차순
		
		// 출력
		for (String name : nameList) {
			System.out.print( name + ",");
		}
		System.out.println();
		
		
		List<Integer>  list2 = Arrays.asList(11, 56, 5, 8, 99);
		for (Integer num : list2) {
			System.out.println(num);
		}
		

	}

}








