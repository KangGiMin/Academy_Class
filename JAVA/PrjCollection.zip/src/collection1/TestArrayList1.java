package collection1;

import java.util.ArrayList;

public class TestArrayList1 {

	public static void main(String[] args) {
		
		int [] arr = new int[3];
		arr[0]     = 10;
		arr[1]     = 20;
		arr[2]     = 30;
		// arr[3]     = 40;  // ArrayIndexOutOfBoundsException: Index 3 out of boundsc

		for (int i = 0; i < arr.length; i++) {
			System.out.print( arr[i] + " " );
		}
		System.out.println();
		
		//----------------------
		ArrayList numList  =  new ArrayList(); 
		numList.add( 10 );
		numList.add( 20 );
		numList.add( 30 );
		numList.add( 40 );
		numList.add( 50.5 );
		numList.add( "인사" );
		
		for (int i = 0; i < numList.size(); i++) {
			System.out.print( numList.get(i) + " "  );
		}
		System.out.println();
		
		//----------------------------
		ArrayList<Integer>  numList2 = new ArrayList<>();
		numList2.add( 10 );
		numList2.add( 20 );
		numList2.add( 30 );
		numList2.add( 40 );
		// numList2.add( 50.5 );   // error : 실수저장 불가
		// numList2.add( "인사" );     // error : 문자저장 불가
		for (int i = 0; i < numList2.size() ; i++) {
			System.out.print( numList2.get(i) + " "  );
		}
		System.out.println();
		
		for (Integer num : numList2) {
			System.out.print( num +  " " );
		}
		System.out.println();
		
	}

}













