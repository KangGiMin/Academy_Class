package array01;

public class TestArray01 {

	public static void main(String[] args) {
		// 안유진  가을  레이  장원영  리즈  이서
		String ive1 = "안유진";
		String ive2 = "가을";
		String ive3 = "레이";
		String ive4 = "장원영";
		String ive5 = "리즈";
		String ive6 = "이서";
		
		System.out.println(ive1);
		System.out.println(ive2);
		System.out.println(ive3);
		System.out.println(ive4);
		System.out.println(ive5);
		System.out.println(ive6);
		
		//----------------------------
		System.out.println();
		// 안유진  가을  레이  장원영  리즈  이서
		String [] ive = new String[6];  // 초기값이 없으면 size 필수
		
		ive[0] = "안유진";
		ive[1] = "가을";
		ive[2] = "레이";
		ive[3] = "장원영";
		ive[4] = "리즈";
		ive[5] = "이서";
		
		System.out.println(ive[0]);
		System.out.println(ive[1]);
		System.out.println(ive[2]);
		System.out.println(ive[3]);
		System.out.println(ive[4]);
		System.out.println(ive[5]);
		
		System.out.println();
		// 초기값이 있으면 new String[8] -> size 적으면 에러
		String [] iveArr = new String[] {
			"안유진", "가을", "레이", "장원영", "리즈", "이서"  // 배열의 초기값
		};
		for( int i=0;i < iveArr.length;i++  ) {
			System.out.println( iveArr[i] );
		}
		
		// 배열의 사이즈는 실행할때 변경할 수 없다
		//iveArr[6] = "카리나";
		//System.out.println( iveArr[6] );
		// ArrayIndexOutOfBoundsException : 실행시 발생한 예죄
	}

}












