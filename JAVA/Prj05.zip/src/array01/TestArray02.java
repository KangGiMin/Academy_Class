package array01;

import java.util.Iterator;

public class TestArray02 {

	public static void main(String[] args) {
		String [] names  = new String[] {
			"지수", "제니", "로제", "리사" 	
		};
		
		// 지수 162cm, 제니 163cm, 로제는 168.7cm, 리사는 166.5cm
		double [] heights = {  162,  163, 168.7, 166.5  };  
		// 초기값이 있으면 new double[] 생략 가능 
		
		// 출력 
		// 지수 : 162.0 cm   0
		// 제니 : 163.0 cm   1
		// ..
		//  평균키 : 
		// 제일큰키 : 로제
		// 제일작은키 : 지수
		// 실수는 소수이하 2자리로 출력하라
		
		for (int i = 0; i < names.length; i++) {
			System.out.printf("%s : %.2f cm\n", 
					names[ i ],  heights[ i ]);
		}
		double  avg = (heights[0] + heights[1] + heights[2] + heights[3]) / 4.0; 
		System.out.println("평균 키:" + avg + "cm" );
		
		String maxName = "";
		double max     = heights[0]; 
	    for(int i=1;i < heights.length ; i++) {
           if( max < heights[i]  ) {
            max     = heights[i];
            maxName = names[i];
           }
	    }
		// System.out.println("제일작은키:" + minName);
		System.out.println("제일 큰 키:" + maxName);
	} 
}







