package array01;

import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayList01 {

	public static void main(String[] args) {
		// "안유진", "가을", "레이", "장원영", "리즈", "이서"
		ArrayList al = new ArrayList();
		al.add("안유진");   // 0
		al.add("가을");     // 1
		al.add("레이");     // 2
		al.add("장원영");   // 3
		al.add("리즈");     // 4
		al.add("이서");     // 5   : al.size() == 6
		
		System.out.println( al.get(3) );
		
		// 0       1                         5
		// 안유진  가을  레이  장원영  리즈  이서 
		for (int i = 0; i < al.size(); i++) {
			System.out.println( al.get(i)  );
		}
		
		// 5     4     3       2     1     0
		// 이서  리즈  장원영  레이  가을  안유진
		for( int i = al.size() - 1 ; i >= 0 ; i = i-1  ) {
			System.out.print( al.get(i) + "," );
		}
		System.out.println();
		
		al.add("카리나");  // size:7(0~6)
		
		// 0 -> 5,  1->4
		for (int i = 0; i < al.size(); i++) {
			System.out.print( al.get( (al.size()-1) - i ) +  ","  );
		}
		System.out.println();
		// 0       1     2     3       4     5    6  
		// 안유진  가을  레이  장원영  리즈  이서 카리나 : al
		
		al.remove(4);  // al.remove("리즈")
		
		// 안유진  가을  레이  장원영  이서 카리나 : al
		System.out.println( al.toString() );
		
		al.add(1.5); // 입력데이터의  type 아무거나 가능 : object -> 문제 
		System.out.println( al.toString() );
		
		// 중요 : 입력되는 데이터는 문자열(이름)만 가능하게 제약
		// String type 만 가능 
		// Generic : <T> 제너릭 - reference type 만 가능
		ArrayList<String> iveList = new ArrayList<String>();
		iveList.add("안유진");
		iveList.add("가을");
		iveList.add("레이");
		iveList.add("장원영");
		iveList.add("리즈");
		iveList.add("이서");
		// iveList.add(1.5); // error 입력불가능 string만 가능
		System.out.println( iveList );
		
		int maxInt  = Integer.MAX_VALUE;   
		// Reference type <- Primitive type
		// Integer        <- int
		// Integer class : int 의 Wrapper Class
		System.out.println( maxInt );
			
		// ArrayList<int> korList = new ArrayList<>();
		ArrayList<Integer> iveAgeList = new ArrayList<Integer>();  // int값저장
		iveAgeList.add(24);
		iveAgeList.add(25);
		iveAgeList.add(23);
		iveAgeList.add(22);
		iveAgeList.add(24);
		iveAgeList.add(23);
		
		System.out.println( iveList );
		System.out.println( iveAgeList );
		
		// Wrapper Class
		// String  -> Stirng
		// int     -> Integer
		// double  -> Double
		// short   -> Short
		// byte    -> Byte
		// float   -> Float
		// boolean -> Boolean
		// char    -> Character 
		// ArrayList<Character> grade = new ArrayList<>();
		
		 

	}

}







