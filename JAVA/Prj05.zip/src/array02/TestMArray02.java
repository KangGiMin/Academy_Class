package array02;

public class TestMArray02 {

	public static void main(String[] args) {
		/*
		String [][] girls = new String[][] {
			{"지수",   "제니", "로제",   "리사"                    },
			{"안유진", "가을", "레이",   "장원영", "리즈",  "이서" },
			{"민지",   "하니", "다니엘", "해린",   "혜인"          }
		};
		*/
		String [][] girls = new String[3][];
		girls[0] = new String[] {"지수",   "제니", "로제",   "리사"};
		girls[1] = new String[] {"안유진", "가을", "레이",   "장원영", "리즈",  "이서" };
		girls[2] = new String[] {"민지",   "하니", "다니엘", "해린",   "혜인"};
		
		
		for (int i = 0; i < girls.length; i++) {
			for (int j = 0; j < girls[i].length; j++) {
				System.out.print( girls[i][j] + " ");
			}
			System.out.println();
		}

	}

}



