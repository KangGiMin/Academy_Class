package array02;

public class TestMArray01 {

	public static void main(String[] args) {
		// 배열의 배열 - 2차원배열처럼 사용
		// [row][col]
		int [][] arr = new int [3][4];
		arr[0][0] = 1;
		arr[0][1] = 2;
		arr[0][2] = 3;
		arr[0][3] = 4;
		
		arr[1][0] = 5;
		arr[1][1] = 6;
		arr[1][2] = 7;
		arr[1][3] = 8;
		
		arr[2][0] = 9;
		arr[2][1] = 10;
		arr[2][2] = 11;
		arr[2][3] = 12;
	
		
		System.out.println( "줄수:"           +  arr.length  );
		System.out.println( "arr[0] 의 칸수 " +  arr[0].length  );
		System.out.println( "arr[1] 의 칸수 " +  arr[1].length  );
		System.out.println( "arr[2] 의 칸수 " +  arr[2].length  );
		
		// 출력
		for(int i=0; i < arr.length ; i++) {
			for(int j=0;j < arr[i].length ;j++) {
				System.out.printf("%3d",  arr[i][j] );
			}
			System.out.print("\n");
		}
		
	}

}




