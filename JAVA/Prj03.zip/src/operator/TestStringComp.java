package operator;

import java.util.Scanner;

public class TestStringComp {
	
	public static void main(String[] args) {
		
		Scanner  in  =  new Scanner(System.in);
		
		String name1 = "이순신";
		String name2 = "이순신";
		
		if( name1 == name2  ) 
			System.out.println("같은 사람");
		else
			System.out.println("다른 사람");
		
		System.out.println("이름을 입력하세요");
		String name3 = "이순신";
		String name4 = in.nextLine();
		// 문자열비교시 == 사용하면 안됨 == 주소비교
		if( name3 == name4 ) 
			System.out.println("같은 사람");
		else
			System.out.println("다른 사람");
		
		//문자열비교는 equals() 로 한다 값비교
		if( name3.equals(name4) == true ) 
			System.out.println("같은 사람");
		else
			System.out.println("다른 사람");
		
		int result = name3.compareTo(name4); 
		if( result > 0  ) {
			System.out.println(name3 + "이 크다");
		}		
		if( result == 0 ) {
			System.out.println("같은 사람");
		}
		if( result < 0  ) {
			System.out.println(name3 + "이 작다");
		}
		
	}
	
}









