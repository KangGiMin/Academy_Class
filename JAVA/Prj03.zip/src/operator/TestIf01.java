package operator;

public class TestIf01 {

	public static void main(String[] args) {
		// 정수/정수 -> 정수
		System.out.println( 7 / 2 );     // 몫
		System.out.println( 7 % 2 );     // 나머지
		System.out.println( 7 / 2.0 );
		System.out.println( 7.0 / 2.0 );
		System.out.println("-------------------");
		
		int  n1 = 7;
		int  n2 = 2;
		System.out.println(  n1 / n2   );   // 정수/정수=정수 3
		System.out.println(  n1 % n2   );   // 1
		
		System.out.println(  (n1 * 1.0) / (n2 * 1.0)   );   // 3.5
		// 강제 형변환 ( casting  )  (double) n1 -> 7.0
		System.out.println(  (double) n1  / (double) n2   );  // 3.5
		
		System.out.println(  3  > 4    );  // false
		System.out.println(  3 == 4    );  // false
		System.out.println(  3 == 3.0  );  
		    // true  자동형변환 3 -> 3.0   3.0 == 3.0 
		
		
		double d1 = 7; // (double) 7
		double d2 = 2;
		System.out.println(  d1 / d2 );  // 3.5
		
		double dd1 = 3.5;
		int    nn1 = (int) dd1;
		System.out.println( nn1 );
		
		System.out.println("-------------------'");
		
		// 비교연산자
		int  age = 20;    
		System.out.println(  age >= 19  );
		System.out.println(  age == 20  );
		// ==  같다,  !=  같지 않다
		// >, < , >=, <=
		String  adult  = "";   // "" : empty string 빈문자열
		if( age > 19 ) 
		{
			adult = "성인";
		} 
		else 
		{
			adult = "미성년자";
		}
		System.out.println(adult);
		
		String  gender = "여자";
		String  sex    = "남";
		if( sex == "남"  ) {
			gender = "남자";
		} /* else {
			//gender = "여자";
		} */
		System.out.println ( gender );
		
		
	} // main

}  // class end











