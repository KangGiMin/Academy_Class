package operator;

import java.time.LocalDateTime;
import java.util.Scanner;

public class TestOperator3 {
	
	public static String ddi ( int thisYear  ) {
		String  ganji = "";
		
		int na2  = thisYear % 12;
		switch( na2  ) {
		case 0:  ganji="원숭이"; break;
		case 1:  ganji="닭";     break;
		case 2:  ganji="개";     break;
		case 3:  ganji="돼지";   break;
		case 4:  ganji="쥐";     break;
		case 5:  ganji="소";     break;
		case 6:  ganji="호랑이"; break;
		case 7:  ganji="토끼";   break;
		case 8:  ganji="용";     break;
		case 9:  ganji="뱀";     break;
		case 10: ganji="말";     break;
		case 11: ganji="양";     break; 
		}
		
		return ganji;
		
	}

	public static void main(String[] args) {
		
		Scanner        in  = new Scanner(System.in);
		LocalDateTime  now = LocalDateTime.now();
		
		System.out.println("현재 날짜 시간 " +now );
			
		// 년도입력 -> 띠 출력
	    int     birthYear = 2025;
	    String  ganji     = "";
	    
	    int     thisYear  = now.getYear(); 
	    System.out.println("올해연도: " + thisYear );
	    ganji             = TestOperator3.ddi( thisYear  );
	    System.out.println("올해띠:   " + ganji );
	    
	    // ---------------------
	    System.out.println("태어난 연도:" );
	    birthYear =  in.nextInt();
	    ganji             = ddi(  birthYear    );
	    System.out.println( ganji );
	    
		

	}

}








