package operator;

import java.util.Scanner;

public class TestOperator {

	public static void main(String[] args) {
		// 키보드롤 데이터를 입력받아 회원관리
		
		// 키보드 준비 - 외부기능( Class )을 불러온다 
		// 자동 import : ctrl + shift + o
		Scanner  in  = new Scanner( System.in );  
		
		// 입력
		// 번호, 이름, 태어난연도, 성별
		// num, name,  birthYear, gender
		// 1, 아이유, 1998, 여
		
		System.out.println("번호를 입력하세요(1~100)");
		int     num        = in.nextInt();
		in.nextLine();   // 입력받은 엔터키를 무시한다
		
		System.out.println("이름을 입력하세요");
		String  name       = in.nextLine();   // 엔터앞의 내용입력받아라
		
		System.out.println("태어난 연도를 입력하세요(2000)");
		int     birthYear  = in.nextInt(); 
		in.nextLine();   // 입력받은 엔터키를 무시한다
		
		System.out.println("성별을 입력하세요(남/여)");
		String  gender     = in.nextLine();
		
		//--------------------------------------------------
		// 계산
		// 나이 = 올해     - 태어난연도
		// age  = thisYear - birthYear
		// 성인 여부 판단
		// 조건을 물어본다 
		int    thisYear = 2025;    
		int    age;    
		age             = thisYear - birthYear;
		
		String adult    = "어른이";
		
		//-------------------------------------------
		// 출력
		// 번호, 이름, 나이
		// num,  name, age,  gender, adult 
		// 번호 : 1
		// 이름 : 아이유
		// 나이 : 25살
		// 성별 : 남자/여자
		// 성인 : 어른이/어린이
		System.out.println("번호:" + num    );
		System.out.println("이름:" + name   );
		System.out.println("나이:" + age    );
		System.out.println("성별:" + gender );
		System.out.println("성인:" + adult   );

	}

}







