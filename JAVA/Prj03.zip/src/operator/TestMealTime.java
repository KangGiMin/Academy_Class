package operator;

import java.time.LocalDateTime;

public class TestMealTime {

	public static void main(String[] args) {
		// int  hour = 16;
		LocalDateTime now = LocalDateTime.now();
		int  hour         = now.getHour(); 
		
		if( hour < 11 ) {
			System.out.println("아침먹을 시간");
		} else {  // hour >= 11
			if( hour < 15 ) {  // hour < 15
				System.out.println("점심먹을 시간");	    
			} else { // hour < 22
				if( hour < 22 )
					System.out.println("저녁먹을 시간");
				else 
					System.out.println("자라");
			}
		}
		System.out.println(hour);

	}

}



