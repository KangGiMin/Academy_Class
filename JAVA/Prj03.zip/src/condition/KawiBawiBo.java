package condition;

import java.util.Random;
import java.util.Scanner;

public class KawiBawiBo {

	public static void main(String[] args) {
		/*
		유저 
		1. 가위
		  컴 1. 가위   비김
		     2. 바위   짐
		     3. 보     이김
		2. 바위
		  컴 1. 가위   이김
		     2. 바위   비김
		     3. 보     짐
		3. 보
		  컴 1. 가위   짐
		     2. 바위   이김
		     3. 보     비김
		 */
		Scanner    in      =  new Scanner(System.in); // 키보드를 사용하겠다
    	int        my      =  3;  // 1:가위, 2: 바위, 3.보
		int        com     =  2; 
		String     result  =  "";
		
		System.out.println( "유저가 선택합니다(1.가위 2.바위 3.보)"  );
		my   =   in.nextInt(); 
		
		// 컴퓨가 자동으로 선택 - random 
		Random   rnd   =  new Random();		
		com            =  rnd.nextInt(3) + 1; // 0, 1, 2 + 1  
		
		System.out.println("컴퓨터의 선택:" +  com);
		
		long   t1 = System.nanoTime();
		if( my == 1 ) {
			if( com == 1 ) result  = "비김";
			if( com == 2 ) result  = "짐";
			if( com == 3 ) result  = "이김";
		}
		if( my == 2 ) {
			if( com == 1 ) result  = "이김";
			if( com == 2 ) result  = "비김";
			if( com == 3 ) result  = "짐";
		}
		if( my == 3 ) {
			if( com == 1 ) result  = "짐";
			if( com == 2 ) result  = "이김";
			if( com == 3 ) result  = "비김";
		}
		
		System.out.println("결과:" + result);
		long   t2 = System.nanoTime();
		long   t  = t2 - t1;
		System.out.println( "실행시간:" + t + " nano 초" );
		System.out.println( "실행시간:" + t / 1000000.0 + " mili 초" );

	}

}









