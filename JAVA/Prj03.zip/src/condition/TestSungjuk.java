package condition;

public class TestSungjuk {

	public static void main(String[] args) {
		// 입력
		// 이름, 국어, 영어, 수학
		// name, kor,   eng, mat
		String  name = "사나";
		int     kor  = 80;
		int     eng  = 90;
		int     mat  = 85; 
		
		// 계산
		// 총점 = 국어 + 영어 + 수학
		int     tot   = kor + eng + mat;   
		// 평균 = (국어 + 영어 + 수학) / 3
		int     avg   =  (kor + eng + mat) / 3;
		// 등급
		/*
		 A : 90~100   90 <= avg <= 100
		 B : 80~89
		 C : 79~79
		 D : 60~69
		 F : 0 ~ 59
		 */
		char    grade = 'F';
		if(  90 <= avg && avg <= 100 ) {
			grade = 'A';					
		} else {
			if( 80 <= avg && avg <= 89 ) {
				grade = 'B';
			} else {
				if( 70 <= avg && avg <= 79  ) {
					grade = 'C';
				} else {
					if(  60 <= avg && avg <= 69 ) {
						grade = 'D';
					} else {
						grade = 'F';
					}
				}
			}
		}
			
		
		
		// 출력
		// 이름, 총점, 평균, 등급
		// name, tot,  avg,  grade
		System.out.println("이름  총점  평균 등급");
		System.out.printf( "%s  %d   %d    %c ",
				          name, tot, avg, grade	);
		
		/*
		 %10.3f  : 전체 10자리수 에 소수이하 3자리 출력
		 %s : String
		 %d : 10진수 decimal
		 %x : 16진수 hexa decimal
		 %c : char
		 %f : double, float
		 
	
		 */
	}
		
}







