package ex01;

import java.time.LocalDateTime;
import java.util.Scanner;

//입력 1줄 -> 결과 1줄
//입력data : 사번,이름,입사일,월급,부서번호
//출력     : 사번,이름,입사일,월급,보너스,수령액,부서명

//금액은 소수이하 두자리로 반올림
//보너스   =  근무연수에 따라 월급의 0.5% 로 계산한다
//수령액   =  월급 + 보너스
//부서명   =  10:인사,20:자재,30:총무,40:연구개발,50:생산,60:서비스

//모든기능은 class에 구현한다.
//입력data
//사번,이름,입사일,월급,부서번호
/*
100,사나,20110101,300.0,10      
200,모모,20120301,270.0,20      
300,정연,20091003,250.0,30      
400,나연,20110105,220.0,40      
500,미나,20180401,170.0,60      
600,쯔위,20150801,200.0,50      
*/

interface  Ipo {
   void  input();
   void  process();
   void  output();
}

// 한줄의 data 담당하는 클래스
class  EmpDTO {
	// Fields
	// 입력data : 사번,이름,입사일,월급,부서번호
	//            empId, empName, hiredate, salary, deptId
	private  int      empId;
	private  String   empName;
	private  String   hiredate;
	private  double   salary;
	private  String   deptId;
	
	//출력     : 사번,이름,입사일,월급,보너스,수령액,부서명
	//           empId,empName,hiredate,salary,bonus,pay,deptName
	private  double   bonus;
	private  double   pay;
	private  String   deptName;
	//--------------------
	
	// Getter / Setter
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public double getBonus() {
		return bonus;
	}
	public void setBonus(double bonus) {
		this.bonus = bonus;
	}
	public double getPay() {
		return pay;
	}
	public void setPay(double pay) {
		this.pay = pay;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	// Constructor 생성자 
	public EmpDTO(int empId, String empName, String hiredate, double salary, String deptId) {
		this.empId = empId;
		this.empName = empName;
		this.hiredate = hiredate;
		this.salary = salary;
		this.deptId = deptId;
	}

	// toString
	@Override
	public String toString() {
		return "EmpDTO [empId=" + empId + ", empName=" + empName + ", hiredate=" + hiredate + ", salary=" + salary
				+ ", deptId=" + deptId + ", bonus=" + bonus + ", pay=" + pay + ", deptName=" + deptName + "]";
	}
	
}

// 업무처리 class
class  Employee implements Ipo {

   private  EmpDTO  emp = null;	
	
   @Override
   public void input() {
	   // 0    1     2         3      4    : li   
	   // 300, 정연, 20091003, 250.0, 30
	   Scanner    in       =  new Scanner(System.in);  
	   System.out.println("입력:사번,이름,입사일,월급,부서번호");
	   String     line     =  in.nextLine();
	   String  [] li       =  line.split(",");
	   
	   int        empId    =  Integer.parseInt( li[0].trim() );
	   String     empName  =  li[1].trim();
	   String     hiredate =  li[2].trim();
	   double     salary   =  Double.parseDouble( li[3].trim() );
	   String     deptId   =  li[4].toUpperCase().trim();
	   
	   emp                 =  new EmpDTO(empId, empName, hiredate, salary, deptId);
	   
	   System.out.println( emp.toString() );
      
   }

   @Override
   public void process() {
	   //300,정연,20091003,250.0,30
	   // 출력     : 사번,이름,입사일,월급,보너스,수령액,부서명
	   //           empId,empName,hiredate,salary,bonus,pay,deptName
	   // 금액은 소수이하 두자리로 반올림
	   // bonus
	   // 보너스                 =  근무연수에 따라 월급의 0.5% 로 계산한다
	   LocalDateTime  now        =  LocalDateTime.now(); // 오늘날짜
	   int            thisYear   =  now.getYear();
	   // System.out.println(thisYear);
	   int            hireYear   =  Integer.parseInt( emp.getHiredate().substring(0, 4) );
	   //System.out.println( hireYear );
	   // 근무연수(years)        =  올해     - 입사연도
	   int            years      =  thisYear - hireYear;
	   double         bonus      =  years * emp.getSalary() * 0.005;
	   emp.setBonus( bonus );
	   //System.out.println( bonus );

	   // pay
	   // 수령액   =  월급 + 보너스 emp.pay = emp.salary + bonus
	   emp.setPay ( emp.getSalary() + bonus ) ; 

	   // deptName
	   // 부서명   =  부서코드 10:인사,20:자재,30:총무,40:연구개발,50:생산,60:서비스
	   String  deptName = null;
	   // if( emp.getDeptId().equals("10")  ) deptName = "인사";
	   switch( emp.getDeptId() ) {
	   case  "10": deptName = "인사";      break;
	   case  "20": deptName = "자재";      break;
	   case  "30": deptName = "총무";      break;
	   case  "40": deptName = "연구개발";  break;
	   case  "50": deptName = "생산";      break;
	   case  "60": deptName = "서비스";    break;
	   default   : deptName = ""; 
	   }
       emp.setDeptName( deptName );
       
       System.out.println( emp );
   }

   @Override
   public void output() {
	   //출력     : 사번,이름,입사일,월급,보너스,수령액,부서명
	   System.out.println("사번 이름   입사일 월급 보너스 수령액 부서명");
       String  msg = String.format("%3d  %-5s %s %.2f %.2f %.2f %s", 
    		   emp.getEmpId(),  emp.getEmpName(), emp.getHiredate(), 
    		   emp.getSalary(), emp.getBonus(),   emp.getPay(),     
    		   emp.getDeptName() );
       System.out.println(msg);
   }
   
   
}

public class TestEmp {

   public static void main(String[] args) {
      
      // int        num   =  3;
      Employee   emp1  =  new  Employee();
      emp1.input();
      emp1.process();
      emp1.output();     

   }

}











