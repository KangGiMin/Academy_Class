package ex11;

public class TestException {

	public static void main(String[] args) {
		/*
		int n1 = 7;
		int n2 = 0;
		int n = n1 / n2;
		System.out.println( n );
		System.out.println("프로그램이 정상적으로 종료되었습니다");
		
		// Exception in thread "main" java.lang.ArithmeticException: / by zero
		// at ex11.TestException.main(TestException.java:8)
		*/
		
		try {
			int n1 = 7;
			int n2 = 0;
			int n = n1 / n2;
			System.out.println( n );
		} catch(ArithmeticException e) {
			System.out.println("잘못된 계산입나다");
		} catch(Exception  e) {
			System.out.println("에러발생");
		} finally {
			System.out.println("프로그램이 종료되었습니다");
		}

	}

}




