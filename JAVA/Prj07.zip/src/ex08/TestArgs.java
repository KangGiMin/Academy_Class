package ex08;

// 가변인자
public class TestArgs {

	public static void main(String[] args) {
		int r1 = add(1,2);
		int r2 = add(1,2,3);
		int r3 = add(1,2,3,4);
		int r4 = add(1,2,3,4,5);	
		int r5 = add(1,2,3,4,5,6,7,8,9,10);	
	}

	private static int add(int ... nums ) {
		int sum = 0;
		for (int i = 0; i < nums.length; i++) {
			sum = sum + nums[i];
			//System.out.print (nums[i] + " ");
		}
		System.out.println("sum:" + sum);
		return 0;
	}

}





