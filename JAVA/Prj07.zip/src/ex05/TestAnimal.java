package ex05;

// 한개의 함수라도 abstract 가 존재하면 
// class 에도 abstract 를 적어야한다 
abstract class Pet { 
	String  name;
	void    eat() {
		System.out.println(name + "이(가) 먹는다");
	}
	abstract void    sound() ;  // abtract -> 코딩({})가 없는 함수  
}

class Dog extends Pet {

	// Override : 재정의한다
	@Override
	void sound() {
		System.out.println("멍멍");		
	}
	
}

class Cat extends Pet {

	@Override
	void sound() {
		System.out.println("야용");		
	}
	
}

class Tiger extends Pet {

	@Override
	void sound() {
		System.out.println("어흥~~~~~~");		
	}
	
}

// 다중 상속 불가능 - 자바, C# 에서 불가능 
/*
class  Kimera  extends Dog, Cat {
	
} 
*/

public class TestAnimal {

	public static void main(String[] args) {
		
		// Pet  pet   =  new Pet(); // abstract 가 있는 class 는 new 안됨
		/*		
		Dog  dog1  =  new Dog();
		dog1.name  =  "제리";
		dog1.eat();
		dog1.sound();
		
		Cat  cat1 = new Cat();
		cat1.name  = "네로";
		cat1.eat();
		cat1.sound();
		*/
		Dog  dog1 = new Dog();
		info( dog1, "제리" );
		
		Cat  cat1 = new Cat();
		info( cat1, "네로" );
		
		Tiger tiger1 = new Tiger();
		info( tiger1, "큰 길량이");

	}

	private static void info(Pet pet, String name) {
		pet.name  =  name;
		pet.eat();
		pet.sound();			
	}

	
	
	/* overloading 
	private static void info(Cat cat1) {
		cat1.name  = "네로";
		cat1.eat();
		cat1.sound();		
	}

	private static void info(Dog dog1) {
		dog1.name  =  "제리";
		dog1.eat();
		dog1.sound();		
	}
	*/

}






