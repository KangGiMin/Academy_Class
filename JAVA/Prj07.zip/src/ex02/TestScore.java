package ex02;

class Score {
	// Fields
	int     num;
	String  name;
	int     kor;
	int     eng;
	int     mat;
	int     tot;
    double  avg;
    char    grade;
    
    // 인자 있는 생성자가 1개라로 있으면 기본생성자가 자동생성되지 않는다 
    public Score(int num, String name, int kor, int eng, int mat) {
		this.num    = num;
		this.name   = name;
		this.kor    = kor;
		this.eng    = eng;
		this.mat    = mat;
	}

    // 기본생성자 
    public Score() {
		// TODO Auto-generated constructor stub
	}

	// methods
	void calcTot() {
    	this.tot = this.kor + this.eng + this.mat;
    }
    
    void calcAvg() {
    	this.avg = (this.kor + this.eng + this.mat) / 3.0;
    }
    
    void calcGrade() {
    	//             0    1    2    3    4    5    6    7    8    9   10
    	char [] g  = {'F', 'F', 'F', 'F', 'F', 'F', 'D', 'C', 'B', 'A', 'A' };
    	this.grade = g[ (int) this.avg / 10  ];
    	/*
    	if( 90 <= this.avg && this.avg <=100  )
    		grade = 'A';
    	else 
    		if( 80 <= this.avg && this.avg < 90  )
    			grade = 'B';
    		else 
    			if( 70 <= this.avg && this.avg < 80  )
    				grade = 'C';
    			else 
    				if( 60 <= this.avg && this.avg < 70 )
    					grade = 'D';
    				else
    					grade = 'F';
    	*/
    }
    
    void disp() {
    	this.calcTot();
		this.calcAvg();
		this.calcGrade();
    	
    	System.out.println("번호 이름 국어 영어 수학 총점 평균 등급");
    	System.out.printf("%d %s %d %d %d %d %.3f %c\n", 
    			this.num, this.name, this.kor, this.eng, this.mat,
    			this.tot, this.avg, this.grade );
    }
}

/*
번호,이름,국어,영어,수학
1,사나,70,80,90
2,모모,0,70,100   
3,쯔위,70,90,90
4,정연,80,90,70
*/

public class TestScore {

	public static void main(String[] args) {
		
		Score  sc1 = new Score();
		sc1.num  = 1;
		sc1.name = "사나";
		sc1.kor  = 70;
		sc1.eng  = 80;
		sc1.mat  = 90;		
		sc1.disp();
		
		Score sc2 = new Score(2,"모모", 0, 70, 100  );	
		sc2.disp();
				

	}

}











