package ex02;

import java.util.ArrayList;

class Member {
	// data : field
	String name;
	String uid;
	String email;
	int    regyear;
	
	// Constructor : 생성자
	public Member() {
		regyear = 2025;
	}
	
	public Member(String name, String uid, String email) {
		this.name  = name;
		this.uid   = uid;
		this.email = email;
	}

	// operation : 기능 - 동작 Method
	void info() {
		System.out.println();
		System.out.println("이름:"   + name );
		System.out.println("아이디:" + uid);
		System.out.println("이메일:" + email);
		System.out.println("가입연도:" + regyear);
	}
}

public class TestMember {

	public static void main(String[] args) {
		
		// int     year = 2000;
		Member  m1   = new Member();
		// m1.info();		
		m1.name      = "정연";
		m1.uid       = "JungY";
		m1.email     = "jy@jyp.com";
		
		// System.out.println("이름:"   +m1.name);
	    m1.info();
	    System.out.println( m1.name );
	    
	    //-------------------------------
	    Member  m2   =  new Member();
	    m2.name      =  "쯔위";
	    m2.uid       =  "zwi";
	    m2.email     =  "zwi@jyp.com";
	    m2.info();
	    
	    //------------------------------------
	    Member  m3    =  new Member("사나", "sana", "sana@jyp.com");
	    m3.info();
	    
	    //=======================================
	    // int [] num  = new int[3];
	    Member [] mArr = new Member[3]; // 주의 Member 가 저장될 변수 3개 생성
	    
	    mArr[0]        = new Member();  //  
	    mArr[0].name   = "정연";
	    mArr[0].uid    = "JungY";
	    mArr[0].email  = "jy@jyp.com";
	    // mArr[0].info();
	    
	    mArr[1]        = new Member("쯔위", "zwi", "zwi@jyp.com");
	    // mArr[1].info();
	    
	    mArr[2]        = new Member("사나", "sana", "sana@jyp.com");
	    // mArr[2].info();
	    
	    for (int i = 0; i < mArr.length; i++) {
			mArr[i].info();
		}
	    
	    //------------------------------------
	    ArrayList<Member>  mList = new  ArrayList<>();
	    Member m = new Member();
	    mList.add( m ) ; 
	    // mList.add( new Member() ) ; 
	    
 
	}

}













