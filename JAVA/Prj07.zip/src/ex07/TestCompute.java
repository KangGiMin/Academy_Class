package ex07;

// overloading
class  Compute {
	int add(int v1, int v2) {
		return  v1 + v2;
	}
	int add(int v1, int v2, int v3) {
		return v1 + v2 + v3;
	}
	double add(double v1, double v2) {
		return v1 + v2;
	}
}

public class TestCompute {

	public static void main(String[] args) {
		Compute  comp1 = new Compute();
		
		int r1 = comp1.add(7, 2);
		System.out.println( r1 );
		
		int r2 = comp1.add(7, 2, 28);
		System.out.println( r2 );
		
		double r3 = comp1.add(5.3, 7.9);
		System.out.println( r3 );
		
		System.out.println( 10 );
		System.out.println( 10.3 );
		System.out.println( "하하" );
	}

}









