package ex04;

class Pet {    // 부모 클래스
	String  name;
	void  eat() {
		System.out.println( name + "(이)가 사료를 먹는다" );
	}
}

class Dog extends Pet {  // 상속 (Inherit ) 자식 클래스

	void  bark() {
		System.out.println("멍멍");
	}
}

class Cat extends Pet  {  // 자식 클래스

	void  meow() {
		System.out.println("야옹");
	}
}

public class TestAnimal {
    // instance : pet
	public static void main(String[] args) {
		Pet   pet = new Pet();
		pet.name  = "마이펫";
		pet.eat();	
		
		Dog   chu  = new Dog();
		chu.name   = "츄";
		chu.eat();
		chu.bark();
		
		Cat   nero = new Cat();
		nero.name  = "네로";
		nero.eat();
		nero.meow();

	}

}
