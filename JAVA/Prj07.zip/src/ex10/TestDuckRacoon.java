package ex10;

import java.awt.dnd.DragGestureEvent;

interface  IDuck {
	void  swim();
}

interface  IRacoon {
	void  dig();
}

class  DuckRacoon implements IDuck, IRacoon {

	@Override
	public void dig() {
		System.out.println("땅을 판다");		
	}

	@Override
	public void swim() {
		System.out.println("헤엄을 친다");		
	}
	
}

public class TestDuckRacoon {

	public static void main(String[] args) {
		DuckRacoon  dr1 = new DuckRacoon();
		dr1.swim();
		dr1.dig();
	}

}





