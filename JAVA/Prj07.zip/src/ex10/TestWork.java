package ex10;

interface  Ipo {
	public abstract void input();
	public abstract void process();
	public abstract void output();
}

class   Work  implements Ipo {

	@Override
	public void input() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void output() {
		// TODO Auto-generated method stub
		
	}
	
}

public class TestWork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
