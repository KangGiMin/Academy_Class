package ex06;

class Animal {
	void speak() {
		System.out.println("동물이 소리를 낸다");
	}
}

class Dog extends Animal {	 
	@Override        // @Override : annotation - 컴파일러에게 알려준다 
	void speak() {   // 부모함수를 재정의하는것(override 된 것)
		System.out.println("명멍");
	}
}

public class TestAnimal {

	public static void main(String[] args) {
		Animal a = new Animal();
		a.speak();
		
		Dog    d = new Dog();
		d.speak();
			
		Animal ani = d;
		ani.speak();

	}

}






