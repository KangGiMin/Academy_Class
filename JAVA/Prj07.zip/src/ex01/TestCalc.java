package ex01;

public class TestCalc {

	// 실인수 (넘겨주즌 데이터) -> 가인수(넘어오는 데이터) 개수, type, 순서가 일치
	// 인수를 너겨받을때 변수를 만들어서 받는다 call by value , 값먼 전달
	public static void main(String[] args) {
		int  n1 = 7;
		int  n2 = 2; 
		int  r; 
		// r = n1 + n2;
		r  = add(7, 2);   // n1, n2 실인수(실제값) argument
		System.out.println( r );
		r  = add(n1, n2, 13);
		System.out.println( r );
	}

	// overloading (오버로딩) : 객체지향언어의 특징중 하나
	// 함수이름이 같아도 인자의 갯수나 type 이 다르면 여러개 만들수 있다
	private static int add(int n1, int n2) { // 가인수(넘겨받을 변수), parameter  
		int n = n1 + n2;
		return  n;
	}
	
	private static int add(int n1, int n2, int n3) { // 가인수(넘겨받을 변수), parameter  
		int n = n1 + n2 + n3;
		return  n;
	}

}







