package ex01;

class  Car {
	// data : 전역변수 Fields
	String  name;
	String  color;
	int     year;
	
	// 생성자 : Constructor - 필수 : 생략하면 컴파일러가 자동으로 추가해줌
	//  public Car() {} 기본 생성자
	// 	new Car() 명령을 수행할 때 초기값 설정 
	//  Car  car1  =  new Car();
	// 기본생성자 (인자 없는)
	public Car() {		
		name  = "";
		color = "";
		year  = 2025; 
	}
	
	// 인자있는 생성자 - 함수(return 없는 함수)
	public Car(String name, String color, int year )  {
		// this.name : 내 객체의 전역변수 name
		this.name  = name;
		this.color = color;
		this.year  = year;
	}
	
	// 기능 : 메소드(method) class 안의 함수
	void info() {
		System.out.println("===================");
		System.out.println("차이름:" + name);
		System.out.println("색상:"   + color);
		System.out.println("연식:"   + year);
	}
}

public class TestCar02 {

	public static void main(String[] args) {
		Car  car1  =  new Car();
		car1.name  =  "아빠차";
		car1.color =  "Black";
		car1.year  =  2022;
		car1.info();
		
		Car   momCar  = new Car();
		momCar.name  = "엄마차";
		momCar.color = "red";
		momCar.year  = 2023;
		momCar.info();
		
		Car   myCar = new Car();
		myCar.name  = "내차";
		myCar.color = "핑크";
		myCar.year  = 2025;
		myCar.info();
		
		Car  myCar2 = new Car("내 두번째 차", "orange", 2025);
		myCar2.info();
	}

}








