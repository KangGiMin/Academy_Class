package ex01;

public class TestCar01 {

	public static void main(String[] args) {
		String name1   = "아빠차";
		String color1  = "Black";
		int    year1   = 2022;
		
		System.out.println("차이름:" + name1);
		System.out.println("색상:"   + color1);
		System.out.println("연식:"   + year1);
		
		String name2   = "엄마차";
		String color2  = "Red";
		int    year2   = 2023;
		
		System.out.println("차이름:" + name2);
		System.out.println("색상:"   + color2);
		System.out.println("연식:"   + year2);
				
		String name3   = "내차";
		String color3  = "Pink";
		int    year3   = 2025;
		
		System.out.println("차이름:" + name3);
		System.out.println("색상:"   + color3);
		System.out.println("연식:"   + year3);
				
		

	}

}
