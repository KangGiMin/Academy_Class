package ex09;

class Duck   {
	void swim() {
		System.out.println("헤엄을 칩니다");
	}
}

/* 모든 함수가 abstract  일때 abstract class -> interface 로 바꿀수 있다
 * interface 도 class  처럼 상속할 수 있다 extends -> implements
 * implements 뒤에는 여러개의 인터페이스를 쓸 수 있다(다중상속처럼 쓸 수 있다)
abstract class Racoon {
	abstract void dig();
}
*/
interface  Racoon {
	void dig();
}


class DuckRacoon extends  Duck implements Racoon {

	@Override
	public void dig() {
		
		System.out.println("땅를 팝니다");
		
	}	
	
}

public class TestDuckRacoon {

	public static void main(String[] args) {
		
		DuckRacoon  dr1 = new DuckRacoon();
		dr1.swim();
		dr1.dig();

	}

}






