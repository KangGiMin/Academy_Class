package ex01;

public class TestFunc01 {
/*
번호,이름,국어,영어,수학
1,사나,70,80,90
*/
/*
   지역변수 : local variable {} 안에서 만든 변수 : {} 안에서만 쓸수 있다 
   전역변수	: global variable 다른{}에서도 사용가능한 변수
 */
	// 전역변수 : 필드변수 Field
	static  int    num;
	static  String name ; 
	static  int    kor;
	static  int    eng;
	static  int    mat;	
	static  int    tot;
	static  int    avg;
	
	public static void main(String[] args) {
		
		//IPO : input + process + output			
		input();   // == TestFunc01.input();
		process();		
		output();
				
	}

	private static void input() {
		//1,사나,70,80,90
		num  = 1;
		name = "사나";
		kor  = 70;
		eng  = 80;
		mat  = 90;	  
	}

	private static void process() {
		// 들여쓰기 : indent 자동정리 : ctrl+i
		// process()
		tot  = kor + eng + mat;
		avg  = tot / 3;
	}

	private static void output() {  // 함수 : 프로그램의 조각
    	// output
	    header();		
		System.out.printf("%d  %s    %d    %d   %d   %d  %d",
				           num, name, kor, eng, mat, tot, avg);		
	}

	private static void header() {
    	System.out.println("번호 이름 국어 영어 수학 총점 평균");	
    }

}



