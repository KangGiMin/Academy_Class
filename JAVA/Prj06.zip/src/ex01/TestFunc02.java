package ex01;

import java.util.Scanner;

/*
번호,이름,국어,영어,수학
1,사나,70,80,90
2,모모,0,70,100   
3,쯔위,70,90,90
4,정연,80,90,70
 */
public class TestFunc02 {
	
	// 데이터
	static  int     num;
	static  String  name;
	static  int     kor;
	static  int     eng;
	static  int     mat;
	static  int     tot;
	static  double  avg;
	
	public static void main(String[] args) {
		input();
		process();
		output();

	}

	// 기능
	private static void input() {
		// 키보드를 준비
		Scanner   in    =  new Scanner(System.in);
		
		System.out.println("번호,이름,국어,영어,수학");
		                          //  li                   0 1    2  3  4          
		String    line  =  in.nextLine();              // "1,사나,70,80,90"
		String [] li    =  line.split(",");            // 문자열을 , 로 나눈다
		num             =  Integer.parseInt( li[0] );  // 1 <- Integer.parseInt( "1" )
		name            =  li[1]; 
		kor             =  Integer.parseInt( li[2] );  // 70 <- "70"
		mat             =  Integer.parseInt( li[3] ); 
		eng             =  Integer.parseInt( li[4] ); 		
	}

	private static void process() {
		
		tot  =  kor + eng + mat;
		avg  =  (double) tot / 3.0;
		
	}

	private static void output() {		
		// 평균은 반올림 소스이하 3자리로 출력 
		System.out.println("번호 이름 국어 영어 수학 총점 평균 학점");
		System.out.printf("%d   %s    %d   %d   %d   %d   %.3f",
				           num, name, kor,eng,  mat, tot, avg );
	}



}











