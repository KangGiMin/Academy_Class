
public class Test01 {
	
	public static void main(String [] args) {
		
		System.out.println("카리나");
		System.out.println("장원영");
		
	}
}
