package ex01;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TextFileReader {

	public static void main(String[] args) throws IOException {
		
		//String          path      =  "D:\\dev\\ws\\java\\PrjIO\\src\\ex01\\";
		String          filename  =  "data.txt";
		
		//FileReader      fr        =  new FileReader( path + filename );
		FileReader      fr        =  new FileReader(  filename );
		BufferedReader  br        =  new BufferedReader( fr ); 
		
		String          line      =  ""; 
		while( (line = br.readLine()) != null   ) {  // file 의 끝까지 읽어온다
			System.out.println( line );
		}
		
		br.close();
		fr.close();

	}

}





