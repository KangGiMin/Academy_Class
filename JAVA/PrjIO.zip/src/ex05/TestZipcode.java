package ex05;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

// DTO : Data Transfer Object, VO(Value Object)
class  ZipcodeDTO {
	// field
	// zipcode,sido,gugun,dong,bunji,seq
	private  String    zipcode; 
	private  String    sido; 
	private  String    gugun; 
	private  String    dong; 
	private  String    bunji; 
	private  int       seq;
	
	// Getter / Setter
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getSido() {
		return sido;
	}
	public void setSido(String sido) {
		this.sido = sido;
	}
	public String getGugun() {
		return gugun;
	}
	public void setGugun(String gugun) {
		this.gugun = gugun;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getBunji() {
		return bunji;
	}
	public void setBunji(String bunji) {
		this.bunji = bunji;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	
	// 생성자
	public ZipcodeDTO() {}
	
	public ZipcodeDTO(String zipcode, String sido, String gugun, 
			String dong, String bunji, int seq) {
		this.zipcode = zipcode;
		this.sido = sido;
		this.gugun = gugun;
		this.dong = dong;
		this.bunji = bunji;
		this.seq = seq;
	}
	
	// method 
	public  String  toAddress() {
		// [135-773] 서울 강남구 개포4동 시영아파트 (1∼25동) 
		String  address = String.format(
				"[%s] %s %s %s %s ", 
				zipcode, sido, gugun, dong, bunji);
		return  address;
	}

	// toString
	@Override
	public String toString() {
		return "Zipcode [zipcode=" + zipcode + ", sido=" + sido + ", gugun=" + gugun + ", dong=" + dong + ", bunji="
				+ bunji + ", seq=" + seq + "]";
	}

}

public class TestZipcode {

	public static void main(String[] args) throws IOException {
        // 조회할 자료를 키보드로 입력받는다
		Scanner         in       =  new Scanner( System.in );
		System.out.println("검색할 도시:");
		String          inSido   =  in.nextLine();
		System.out.println("동명/건물명:");
		String          inDong   =  in.nextLine();

		String          path     = "D:\\dev\\ws\\java\\PrjIO\\src\\ex05\\";
		String          filename = "zipcode.csv";
		
		// 입력 data 파일 준비
		FileReader      fr        =  new FileReader( path + filename );
		BufferedReader  br        =  new BufferedReader( fr );
		
		// 출력 파일준비
		String          ofilename =  "d:\\dev\\data\\zipcode_out.txt";
		FileWriter      fw        =  new FileWriter( ofilename, true );  
		BufferedWriter  bw        =  new BufferedWriter( fw );
		
		String          title     =  br.readLine();
		System.out.println( title );
		String          line      =  "";
		int             cnt       =  0;
		int             totcnt    =  0; 
		while( (line= br.readLine() ) != null) {
		//	ZipcodeDTO  zipcodeDTO =  new ZipcodeDTO(
		//			"600-123", sido, gugun, dong, bunji, seq);
			String  [] li = line.split(",");
			
			ZipcodeDTO  dto = new  ZipcodeDTO();
			dto.setZipcode( li[0] );
			dto.setSido(    li[1] );
			dto.setGugun(   li[2] );
			dto.setDong(    li[3] );
			dto.setBunji(   li[4] );
			dto.setSeq(  Integer.parseInt( li[5] ) );
			
			String  sido =  dto.getSido();
			String  dong =  dto.getDong();
					
			if( sido.equals(inSido)  )   { // li[1] == inSido
				if( dong.contains( inDong ) ) {
					System.out.println( dto.toAddress() );
					bw.write( dto.toAddress() + "\n");
					cnt++;
				}  // if dong end 
			}  // if sido end					 
			//System.out.println( dto.toString() );
			totcnt++;
		}   // while end
		bw.write("============================\n");
		System.out.println("조회건수:" + cnt);
		System.out.println("전체건수:" + totcnt);
				
		br.close();
		bw.close();		
		fr.close();
		fw.close();

	}

}









