package ex04;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TestZipcode {

	public static void main(String[] args) throws IOException {
		String          path       =   "D:\\dev\\ws\\java\\PrjIO\\src\\ex04\\";
		String          filename   =   "zipcode.txt";		
		
		FileReader      fr         =   new  FileReader( path + filename );
		BufferedReader  br         =   new  BufferedReader( fr );
		
		String          title      =   br.readLine();  // 제목줄을 skip
		String          line       =   "";		
		int             cnt        =   0;
		int             totcnt     =   0;
		
		while( ( line = br.readLine() ) != null ) {      // 파일끝까지 반복
			// zipcode,sido,gugun, dong,                 bunji,  seq
			// 135-807,서울,강남구,개포1동 우성3차아파트,(1∼6동),2
			String []  li        =  line.split(",");
			String     zipcode   =  li[0];
			String     sido      =  li[1];
			String     gugun     =  li[2];
			String     dong      =  li[3];
			String     bunji     =  li[4];
			int        seq       =  Integer.parseInt( li[5] );
			if(  sido.equals("부산") == true 
				  &&	dong.contains("현대백화점") == true ) {
				System.out.println( line );
				cnt = cnt + 1;
			}
			totcnt = totcnt + 1;
		}		
		
		System.out.println(cnt + "건 출력했습니다");
		System.out.println(filename + " 은 전체 " + totcnt + "건 입니다");
		br.close();
		fr.close();

	}

}




