package ex06;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TestFileWriter {

	public static void main(String[] args) throws IOException {
		String          fn   = "d:\\dev\\data\\out1.txt";
		// 동일파일 있으면  overwrite
		//          없으면  new file 생성
		// FileWriter      fw   = new FileWriter( fn, false );
		
		// 동일파일 있으면  append 추가
		//          없으면  new file 생성
		FileWriter      fw   = new FileWriter(fn, true); 
		
		BufferedWriter  bw   = new BufferedWriter( fw );
				
		bw.write("카리나");
		bw.write(",");
		bw.write("010-1234-4567");
		bw.write("\n");
		
		
		bw.close();
		fw.close();
		
		System.out.println( fn + " 파일이 생성되었습니다. ");
	}

}









