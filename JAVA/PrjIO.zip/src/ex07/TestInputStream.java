package ex07;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TestInputStream {

	public static void main(String[] args) throws IOException {
		// byte 단위로 입출력 : ~Stream
		String            path   =
				TestInputStream.class.getResource("").getPath();
		String            inFile =  path + "aaa.txt";
		System.out.println( inFile );
		// /D:/dev/ws/java/PrjIO/bin/ex07/aaa.txt
		FileInputStream   fis    =  new FileInputStream( inFile );
		
		int ch;
		while( (ch = fis.read() ) != -1 ) {   // 한 바이트씩 읽어온다
			// -1 : EOF - End Of File : window - ^z(ctrl+z)
			//                          unix   - 0xff : -1
			System.out.print( (char) ch );  // char : 1문자 처리한다
		}
		fis.close();

	}

}





