package ex07;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestOutputStream {

	public static void main(String[] args) throws IOException {
		String            fname = "D:\\dev\\ws\\java\\PrjIO\\src\\ex07\\aaa.txt";
		FileOutputStream  fos   = new FileOutputStream( fname ); 
		
		//for (int ch = 'A'; ch <= 'Z'; ch++) {
		for (int ch = 97; ch <= 97+26; ch++) {
			fos.write( ch );
		}
		
		fos.close();
		System.out.println("저장되었습니다");
	}

}






