package ex02;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TextFileReader {

	public static void main(String[] args) throws IOException {
//		1. data.txt 파일을 준비한다  (/ slash , \: back slash)
	//	String    path      =  "D:\\dev\\ws\\java\\PrjIO\\src\\ex02\\";
		String       path      =  "D:/dev/ws/java/PrjIO/src/ex02/";
		String       filename  =  "data.txt";
	   
//		2. 파일읽기기능을 호출한다
		FileReader      fr      =  new FileReader( path + filename );  
//		3. 버퍼읽기기능도 호출한다
		BufferedReader  br      =  new BufferedReader( fr ); 
//		4. 한줄을 저장할 변수를 준비
		String          line    =  ""; 
//		5. 첫줄을 읽어서 버린다
//		   번호,이름,국어,영어,수학 .
		String           title  =  br.readLine();
//		6. 파일끝까지 반복해서 읽어온다		
		while( ( line  = br.readLine()  ) != null   ) {			
//		   line : "1,민지,100,90,80"
//		   각 변수에 짤라서 담는다 li[] = "1" "민지" "100" "90" "80"
		   String []  li   =  line.split(",");
		   int        num  =  Integer.parseInt( li[0].trim() );  // "1"
//		   숫자로 바꾼다, 국어, 영어, 수학
		   String     name =  li[1].trim();
		   int        kor  =  Integer.parseInt( li[2].trim() );
		   int        eng  =  Integer.parseInt( li[3].trim() );
		   int        mat  =  Integer.parseInt( li[4].trim() );
//		   총점 = 극어 +  영어 + 수학
		   int        tot  =  kor + eng + mat;
//		   평균 = 총점 / 3
		   double     avg =  tot / 3.0;
//		   출력한다		
           System.out.printf("%d %s %d %d %d %d %.3f\n",
        		   num, name, kor, eng, mat, tot, avg);
		}	 
//		10.파일을 닫는다
		br.close();
	    fr.close();
	}
	
}

	
	