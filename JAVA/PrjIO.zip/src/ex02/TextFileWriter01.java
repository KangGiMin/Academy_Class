package ex02;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileWriter01 {

	public static void main(String[] args) throws IOException  {
		
		//output();	
		
		input();
	
	}

	private static void input() throws IOException {
		String       filename  =  "out1.txt";
		
		FileReader       fr    =  new FileReader( filename );
		BufferedReader   br    =  new BufferedReader( fr );   
		String          line   = "";
		line                   = br.readLine();
		System.out.println( line );
		line                   = br.readLine();
		System.out.println( line );
		line                   = br.readLine();
		System.out.println( line );
		line                   = br.readLine();
		System.out.println( line );
		line                   = br.readLine();
		System.out.println( line );
		
		fr.close();
		
	}

	private static void output() throws IOException {
		String       filename =  "out1.txt";
		
		FileWriter   fw       =  new FileWriter( filename );
		
		// d:\backup\newdata\a\test1.txt
				
		fw.write("이름\n"); // escape sequence  : d:\backup\newdata\a\test1.txt
		fw.write("가나\n");
		fw.write("히나\n");			
		fw.write("다나\n");		
		fw.write("사나\n");		
		fw.write("미나\n");		
		fw.close();
		
	    System.out.println("저장되었습니다");
		
	}

}






