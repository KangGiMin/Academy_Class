package ex03;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

// 1,민지,100,90,80 
class  NewJeansDTO {
	// Fields
	private  int      num;
	private  String   name;
	private  int      kor;
	private  int      eng;
	private  int      mat;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMat() {
		return mat;
	}
	public void setMat(int mat) {
		this.mat = mat;
	}
	
	public int  getTot() {
		return  kor + eng + mat;
	}
	
	public double  getAvg() {
		return  getTot() / 3.0;
	}
	
	public void info() {
		
		System.out.printf("%d  %s  %d  %d  %d %d %.3f\n", 
				num, name, kor, eng, mat, getTot(), getAvg() );
		
	}
	
	
}

public class TestNewJeans {
    /*
    1. data.txt 파일을 준비한다
	2. 파일읽기기능을 호출한다
 	3. 버퍼읽기기능도 호출한다 	
	4. 한줄을 저장할 변수를 준비
	
 	5. 첫줄을 읽어서 버린다
	   번호,이름,국어,영어,수학 .
	6. 파일끝까지 반복해서 읽어온다
	   1,민지,100,90,80 -> 별도의 class 를 생성한다
	   각 변수에 짤라서 담는다
	   숫자로 바꾼다, 극어, 영어, 수학
	   총점 = 극어 +  영어 + 수학'
	   평균 = 총점 / 3
	   출력한다
	 
	   10.파일을 닫는다      
     */
	public static void main(String[] args) throws IOException {		
		String    path       =  "D:/dev/ws/java/PrjIO/src/ex03/";
		String    filename   =  "data.txt";
		
		FileReader      fr    =  new  FileReader( path + filename );
		BufferedReader  br    =  new  BufferedReader( fr );
		
		String          line  = "";
		br.readLine();   // 제목줄 skip
		
		while( (line = br.readLine() ) != null  ) {
			// line  "1,민지,100,90,80"
			//        0   1     2     3     4   <- line.split(",")
			// li [] "1" "민지" "100" "90" "80"
			String [] li =  line.split(",");
			
			NewJeansDTO   njz    =  new NewJeansDTO( );
			int           num    =  Integer.parseInt( li[0].trim() );
			njz.setNum( num );   // njzDTO.num = 1;
			String        name   =  li[1];
			njz.setName( name );
			int           kor    =  Integer.parseInt( li[2]  );
			njz.setKor( kor );
			int           eng    =  Integer.parseInt( li[3] );
			njz.setEng( eng );
			int           mat    =  Integer.parseInt( li[4] );
			njz.setMat( mat );
			
			njz.info();			
			
		}
		
		br.close();
		fr.close();
	}

}








