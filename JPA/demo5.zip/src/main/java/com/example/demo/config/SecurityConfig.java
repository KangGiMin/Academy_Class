package com.example.demo.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.example.demo.model.Authority;
import com.example.demo.model.Member;
import com.example.demo.model.MemberUserDetails;
import com.example.demo.repository.AuthorityRepository;
import com.example.demo.repository.MemberRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class SecurityConfig {
		
	
	// JPA db 에서 회원정보와 권한정보를 가져오기
	// Member table 에서 회원정보 조회
	@Bean  
	public  UserDetailsService  userDetailsServiceCustom (
		MemberRepository    memberRepository,
		AuthorityRepository authorityRepository
			) {		
		return  new  UserDetailsService() {

			// username : 입력한 로그인 id -> 이메일
			@Override
			public UserDetails loadUserByUsername(String username) 
					throws UsernameNotFoundException {
				// db(Member)에서 사용자 id ( email )를 가져온다
				var     email  = username.toLowerCase();
				// Member 정보 조회
				Member  member = memberRepository
					.findByEmailIgnoreCase( email )
					.orElseThrow();
			    
				log.info("member : {}", member);
				
				// 권한 정보조회
				List< Authority >  authorites = authorityRepository
						.findByMember( member );
				
				log.info("authorites : {}", authorites);
				
				return new MemberUserDetails(member, authorites );
			}
			
		}; 
				
	}
	
	@Bean
	public  SecurityFilterChain securityFilterChain(HttpSecurity http) 
	        throws Exception {
		// withDefaults()  오류 : The method withDefaults() is undefined for the type SecurityConfiguration
	    // withDefaults()는 아무 설정도 하지 않는 Customizer<T>를 돌려주는 도우미(“기본값으로 둔다”는 의미).
	    // import static org.springframework.security.config.Customizer.withDefaults; 필요
	    // 아니면 Customizer.withDefaults() 로 변경
		http
		  // 페이지별 권한 설정 
		  .authorizeHttpRequests( authorize -> authorize
			.requestMatchers("/", "/home").permitAll()	  
			.requestMatchers("/member/**").hasAuthority("ROLE_ADMIN")
			.anyRequest().authenticated() )	// 로그인하지 않은 사용자는 접근할 수 없다	  
		  .formLogin( Customizer.withDefaults() )
		  .logout( Customizer.withDefaults() );
		
		return  http.build();
		
	}
	
	// password BCrypt 암호화 해주는 함수 : 필수
	@Bean
	public  PasswordEncoder   passwordEncoder() {
		return  new BCryptPasswordEncoder();
	}
	
}





