package com.example.demo.config;

import static org.springframework.security.config.Customizer.withDefaults;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;

import com.example.demo.model.Authority;
import com.example.demo.model.Member;
import com.example.demo.model.MemberUserDetails;
import com.example.demo.repository.AuthorityRepository;
import com.example.demo.repository.MemberRepository;

@Configuration
public class SecurityConfig {
//    JDBC 제거(커스텀만 사용) 	
//    JdbcUserDetailsManager : users, authories table 사용
//    @Bean
//    UserDetailsManager userDetailsManagerJdbc(DataSource dataSource) {
//          return new JdbcUserDetailsManager(dataSource);
//    }
    
    // 반드시 같이 구현해야함
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    
    // Member Table 롤 로그인하기 : Custom 로그인
    @Bean
    public  UserDetailsService userDetailsServiceCustom2(
    		MemberRepository memberRepository,
    		AuthorityRepository authorityRepository ) {


    	return new UserDetailsService() {
    		@Override
    		public UserDetails loadUserByUsername(String username)
    				throws UsernameNotFoundException {
    			var email = username.toLowerCase();   // 이메일 소문자로
    			Member member = memberRepository
    					.findByEmailIgnoreCase(email)
    					.orElseThrow();

    			List<Authority> authorities = authorityRepository
    					.findByMember(member);

    			return new MemberUserDetails(member, authorities );
    		}
    	};
    }
    
    // withDefaults()  오류 : The method withDefaults() is undefined for the type SecurityConfiguration
    // withDefaults()는 아무 설정도 하지 않는 Customizer<T>를 돌려주는 도우미(“기본값으로 둔다”는 의미).
    // import static org.springframework.security.config.Customizer.withDefaults; 필요
    // 아니면 Customizer.withDefaults() 로 변경
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http,  
            	RememberMeServices rememberMeServices     // db 로그인위해 추
            )		throws Exception {
           http                   
                   .authorizeHttpRequests(authorize -> authorize
                           .requestMatchers("/", "/home").permitAll()
                           .requestMatchers("/member/**").hasAuthority("ROLE_ADMIN")
                           .anyRequest().authenticated())
                   
                   // .rememberMe(withDefaults())   // 자동로그인
                   .rememberMe(remember -> remember
                           .rememberMeServices(rememberMeServices)) // db 자동로그인
                   
                   .formLogin( login -> login
                		   .loginPage("/login")     // controller  
                		   .defaultSuccessUrl("/")  // login 성공시 이동하는 주소  
                		   .usernameParameter("username")
                		   .passwordParameter("password")
                		   .permitAll()     // permit all for /login
                    )
                   
                   .logout( logout -> logout
                		   .logoutUrl("/logout")
                		   .logoutSuccessUrl("/home")
                		   .permitAll()     // permit all for /logout                		   
                	);           
           
           return http.build();
    }
    
    // 자동로그인구현
    @Bean
    PersistentTokenRepository PersistentTokenRepository(DataSource dataSource) {
        JdbcTokenRepositoryImpl repository = new JdbcTokenRepositoryImpl();
        repository.setDataSource(dataSource);
        return repository;
    }

    // 자동로그인구현
    @Bean
    RememberMeServices rememberMeServices(
        UserDetailsService UserDetailsService,
        PersistentTokenRepository tokenRepository) {
        
        return new PersistentTokenBasedRememberMeServices(
               "myRememberMeKey",
               UserDetailsService,
               tokenRepository);
    }
}
    
