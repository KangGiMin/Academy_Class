package com.example.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Member;   

@RestController
public class ApiController {
	private List<Member> members = List.of(
		new Member(1L, "카리나", "Karina@naver.com", null),	
		new Member(2L, "허태훈", "HeoTaeHoon@naver.com", null),	
		new Member(3L, "윈터",   "Winter@naver.com", null),	
		new Member(4L, "장원영", "Jang10@naver.com", null)				
	);
	
	@GetMapping("/api/members")
	public  List<Member>  getMembers(  ) {
		return  members;    
	}
	
}















