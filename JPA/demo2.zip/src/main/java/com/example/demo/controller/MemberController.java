package com.example.demo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.model.Member;   

@Controller
public class MemberController {
	private List<Member> members = List.of(
		new Member(1L, "카리나", "Karina@naver.com", null),	
		new Member(2L, "허태훈", "HeoTaeHoon@naver.com", null),	
		new Member(3L, "윈터",   "Winter@naver.com", null),	
		new Member(4L, "장원영", "Jang10@naver.com", null)				
	);
	
	@GetMapping("/member/list")
	public  String  getMembers( Model model  ) {
		model.addAttribute("members", members);
		return "/member-list";   // member-list.html(thymeleaf) 
	}
	
}















