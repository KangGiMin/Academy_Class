package com.example.demo.controller;

import java.util.List;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Member;

import lombok.extern.slf4j.Slf4j;   

@Slf4j
@Controller
public class MemberController {
	private List<Member> members = List.of(
		new Member(1L, "카리나", "Karina@naver.com", null),	
		new Member(2L, "허태훈", "HeoTaeHoon@naver.com", null),	
		new Member(3L, "윈터",   "Winter@naver.com", null),	
		new Member(4L, "장원영", "Jang10@naver.com", null)				
	);
	
	@GetMapping("/member/list")
	public  String  getMembers( Model model  ) {
		model.addAttribute("members", members);
		return "/member-list";   // member-list.html(thymeleaf) 
	}
	
	@GetMapping("/home")
	public  ModelAndView getHome(@AuthenticationPrincipal UserDetails userDetails) {
		log.info("userDetails:{}", userDetails);
		ModelAndView  mv = new ModelAndView();
		mv.addObject("user", userDetails);
		mv.setViewName("/home");
		return mv;
	}
	
	@GetMapping("/thyme")
	public   String   thyme() {
		return "/thyme";
	}
	
}















