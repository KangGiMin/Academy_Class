--full customization
INSERT INTO member(name, email, password) VALUES('카리나', 'Karina@naver.com', '$2a$12$hYUqLSsCfWsFxQd9w8AUOeJvXx4ICsK/inDl5rcoN4/FUdNHE33.e');
INSERT INTO member(name, email, password) VALUES('허태훈', 'HeoTaeHoon@naver.com', '$2a$12$hYUqLSsCfWsFxQd9w8AUOeJvXx4ICsK/inDl5rcoN4/FUdNHE33.e');
INSERT INTO member(name, email, password) VALUES('윈터', 'Windter@naver.com', '$2a$12$hYUqLSsCfWsFxQd9w8AUOeJvXx4ICsK/inDl5rcoN4/FUdNHE33.e');
INSERT INTO member(name, email, password) VALUES('장원영', 'Jangwonyoung@naver.com', '$2a$12$hYUqLSsCfWsFxQd9w8AUOeJvXx4ICsK/inDl5rcoN4/FUdNHE33.e');
INSERT INTO authority(authority, member_id) VALUES('ROLE_USER', 1);
INSERT INTO authority(authority, member_id) VALUES('ROLE_USER', 2);
INSERT INTO authority(authority, member_id) VALUES('ROLE_ADMIN', 2);
INSERT INTO authority(authority, member_id) VALUES('ROLE_USER', 3);
INSERT INTO authority(authority, member_id) VALUES('ROLE_USER', 4);
INSERT INTO authority(authority, member_id) VALUES('ROLE_ADMIN', 4);
